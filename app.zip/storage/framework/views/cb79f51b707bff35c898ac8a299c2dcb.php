<nav class="navbar">
    <div class="container navbar-content-wrapper">
        <a class="navbar-brand" href="<?php echo e(route('products.index')); ?>">
            <img src="<?php echo e(asset('images/logo1.png')); ?>" alt="Logo Tienda Friki" class="logo-image">
        </a>
        <div class="navbar-links">
            <a href="<?php echo e(route('products.index')); ?>">Inicio</a>
            <a href="<?php echo e(route('products.byCategory', 'juegos-digitales')); ?>">Juegos</a>
            <a href="<?php echo e(route('products.byCategory', 'cosmeticos')); ?>">Cosméticos</a>
            <a href="<?php echo e(route('products.byCategory', 'tarjetas-de-regalo')); ?>">Tarjetas</a>
            <a href="<?php echo e(route('products.byCategory', 'accesorios')); ?>">Accesorios</a>
        </div>
        <div class="navbar-actions">
            <form action="<?php echo e(route('products.search')); ?>" method="GET" style="display: flex;">
                <input type="search" name="query" placeholder="Buscar..." class="search-bar" value="<?php echo e(request('query') ?? ''); ?>">
                <button type="submit" style="background: none; border: none; color: var(--text-color); cursor: pointer; font-size: 1.2rem; margin-left: -2rem;">🔍</button>
            </form>

            <a href="<?php echo e(route('cart.index')); ?>">🛒</a>

            <?php if(auth()->guard()->check()): ?>
                <span style="margin-left: 1rem;"><?php echo e(Auth::user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>" 
                       onclick="event.preventDefault(); this.closest('form').submit();" 
                       style="margin-left: 1rem;">
                        Salir
                    </a>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" style="margin-left: 1rem;">👤 Login</a>
                <a href="<?php echo e(route('register')); ?>" style="margin-left: 1rem;">Registro</a>
            <?php endif; ?>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\Ecomerce-Tmedio\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>