

<?php $__env->startSection('title', 'Nuestros Productos'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($searchQuery)): ?>
        <h1>Resultados para: "<?php echo e($searchQuery); ?>"</h1>
    <?php elseif(isset($currentCategory)): ?>
        <h1><?php echo e($currentCategory->name); ?></h1>
    <?php else: ?>
        <h1>Nuestros Productos</h1>
    <?php endif; ?>
    
    <div class="product-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('products.show', $product)); ?>">
                <div class="product-card">
                    <img src="<?php echo e($product->image_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="Imagen de <?php echo e($product->name); ?>">
                    <div class="product-card-body">
                        <h3 class="product-card-title"><?php echo e($product->name); ?></h3>
                        <p class="product-card-price">$<?php echo e(number_format($product->price, 2)); ?></p>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No hay productos disponibles en este momento.</p>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecomerce-Tmedio\resources\views/products/index.blade.php ENDPATH**/ ?>