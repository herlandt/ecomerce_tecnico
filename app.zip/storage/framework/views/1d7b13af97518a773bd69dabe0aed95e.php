

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="product-detail-layout">
        <div class="product-detail-image">
             <img src="<?php echo e($product->image_url ?? 'https://via.placeholder.com/400x400'); ?>" alt="Imagen de <?php echo e($product->name); ?>">
        </div>

        <div class="product-detail-info">
            <h1><?php echo e($product->name); ?></h1>
            <p style="font-size: 2rem; font-weight: bold; color: var(--primary-color);">$<?php echo e(number_format($product->price, 2)); ?></p>
            
            <div class="product-meta">
                <p><strong>Categoría:</strong> <?php echo e($product->category->name); ?></p>
                <?php if($product->platform): ?>
                    <p><strong>Plataforma:</strong> <?php echo e($product->platform->name); ?></p>
                <?php endif; ?> 
                <?php if($product->game): ?>
                    <p><strong>Juego Asociado:</strong> <?php echo e($product->game->name); ?></p>
                <?php endif; ?>
            </div>

            <hr>

            <h3>Descripción</h3>
            <p><?php echo e($product->description); ?></p>

          <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
    <?php echo csrf_field(); ?> <button type="submit" style="padding: 1rem 2rem; background-color: var(--primary-color); color: white; border: none; border-radius: 5px; font-size: 1rem; cursor: pointer; margin-top: 1rem;">
        Añadir al Carrito
    </button>
</form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecomerce-Tmedio\resources\views/products/show.blade.php ENDPATH**/ ?>