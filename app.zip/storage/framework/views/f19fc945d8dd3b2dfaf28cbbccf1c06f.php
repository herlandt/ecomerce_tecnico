

<?php $__env->startSection('title', 'Mi Carrito de Compras'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Mi Carrito</h1>

    <?php if(!empty($cartItems)): ?>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 2px solid var(--border-color);">
                    <th style="text-align: left; padding: 1rem;">Producto</th>
                    <th style="text-align: center; padding: 1rem;">Cantidad</th>
                    <th style="text-align: right; padding: 1rem;">Precio Unitario</th>
                    <th style="text-align: right; padding: 1rem;">Subtotal</th>
                    <th style="text-align: center; padding: 1rem;">Acción</th> </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 1rem;">
                            <div style="display: flex; align-items: center;">
                                <img src="<?php echo e($item['image_url'] ?? 'https://via.placeholder.com/100x100'); ?>" alt="<?php echo e($item['name']); ?>" style="width: 80px; height: 80px; object-fit: cover; border-radius: 5px; margin-right: 1rem;">
                                <span><?php echo e($item['name']); ?></span>
                            </div>
                        </td>
                        <td style="text-align: center; padding: 1rem;"><?php echo e($item['quantity']); ?></td>
                        <td style="text-align: right; padding: 1rem;">$<?php echo e(number_format($item['price'], 2)); ?></td>
                        <td style="text-align: right; padding: 1rem;">$<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></td>
                        
                        <td style="text-align: center; padding: 1rem;">
                            <form action="<?php echo e(route('cart.remove', $id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" style="background: none; border: none; color: #ff4d4d; cursor: pointer; font-size: 1.2rem;">
                                    🗑️
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="text-align: right; margin-top: 2rem;">
            <h2 style="font-size: 2rem;">Total: <span style="color: var(--primary-color);">$<?php echo e(number_format($total, 2)); ?></span></h2>
            <form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="submit" style="padding: 1rem 2rem; background-color: var(--primary-color); color: white; border: none; border-radius: 5px; font-size: 1rem; cursor: pointer;">
        Proceder al Pago
    </button>
</form>
        </div>

    <?php else: ?>
        <div style="background-color: var(--card-bg); padding: 2rem; text-align: center; border-radius: 8px;">
            <h2>Tu carrito está vacío.</h2>
            <p>¡Añade algunos productos para empezar!</p>
            <a href="<?php echo e(route('products.index')); ?>" style="display: inline-block; margin-top: 1rem; padding: 0.8rem 1.5rem; background-color: var(--primary-color); color: white; border-radius: 5px;">Ver Productos</a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecomerce-Tmedio\resources\views/cart/index.blade.php ENDPATH**/ ?>